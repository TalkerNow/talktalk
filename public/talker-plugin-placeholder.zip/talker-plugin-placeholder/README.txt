Talker — placeholder zip

Brique lundi 15/9 — zip réel ensuite.

Ceci n'est PAS encore l'extension WordPress.
Le fichier sert à tester le parcours : Télécharger → WP-Admin → Téléverser.

Pas de lien WordPress.org. Le zip réel suivra.
